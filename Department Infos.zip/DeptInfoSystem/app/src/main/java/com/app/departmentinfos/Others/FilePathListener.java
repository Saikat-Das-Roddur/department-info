package com.app.departmentinfos.Others;

public interface FilePathListener {
    void filePath(String filePath);
}
